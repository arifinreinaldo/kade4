package viewer.fb.rei.footballmatchscheduleviewer.util

import android.graphics.Color

/**
 * Created by sapuser on 10/29/2018.
 */
const val apiKey = "1"
const val baseUrl = "https://www.thesportsdb.com/api/v1/json/"
const val leagueID = "4328"
const val dbName = "FootballManager.db"
var loading = intArrayOf(Color.RED,Color.BLUE)
