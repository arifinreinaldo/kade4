package viewer.fb.rei.footballmatchscheduleviewer.view.MatchSchedule

import viewer.fb.rei.footballmatchscheduleviewer.structure.League
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueEvent

/**
 * Created by sapuser on 11/26/2018.
 */
interface MatchScheduleView {
    fun stopLoading()
    fun showLeagueList(value:List<League>)
    fun showLeagueDisplay(listEvents: List<LeagueEvent>)
}