package viewer.fb.rei.footballmatchscheduleviewer.view.MatchSchedule

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import viewer.fb.rei.footballmatchscheduleviewer.structure.League
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueEvent
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueEventList
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueList
import viewer.fb.rei.footballmatchscheduleviewer.util.*

/**
 * Created by sapuser on 11/26/2018.
 */
class MatchSchedulePresenter(val view: MatchScheduleView){

    fun getAllLeagueData(functionRest: String): LeagueList {
        val leagues = arrayListOf<League>()
        var value = LeagueList(leagues)
        apiService.getAllLeague(apiKey)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        { league ->
                            getLeagueList(league, functionRest)
                        },
                        {
                            err("Batal")
                            it.printStackTrace()
                        }
                )
                .collectDispose(bin)
        return value
    }
    fun getLeagueList(events: LeagueList, functionRest: String) {
        val listLeague = events.leagues!!
        view.showLeagueList(listLeague)
    }
    fun getLeagueSchedule(functionRest: String, idLiga: String): LeagueEventList {
        var value = LeagueEventList()
//        dbg("CALL Schedule liga $idLiga")
//        val events: MutableList<LeagueEvent> = mutableListOf()
//        view.stopLoading()
//        view.showLeagueDisplay(events)
        apiService.getLeagueSchedule(apiKey, functionRest, idLiga)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                        { league ->
                            value = league
                            view.stopLoading()
                            view.showLeagueDisplay(league.events!!)
                        },
                        {
                            view.stopLoading()
                            it.printStackTrace()
                        }
                )
                .collectDispose(bin)
        return value
    }
}