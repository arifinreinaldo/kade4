package viewer.fb.rei.footballmatchscheduleviewer

import io.reactivex.android.plugins.RxAndroidPlugins
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.Schedulers
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import viewer.fb.rei.footballmatchscheduleviewer.structure.League
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueEvent
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueEventList
import viewer.fb.rei.footballmatchscheduleviewer.structure.LeagueList
import viewer.fb.rei.footballmatchscheduleviewer.util.formatDayddMMMyyyy
import viewer.fb.rei.footballmatchscheduleviewer.view.MatchSchedule.MatchSchedule
import viewer.fb.rei.footballmatchscheduleviewer.view.MatchSchedule.MatchSchedulePresenter
import viewer.fb.rei.footballmatchscheduleviewer.view.MatchSchedule.MatchScheduleView


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Mock
    private
    lateinit var view: MatchScheduleView

    lateinit var match: MatchSchedulePresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        match = MatchSchedulePresenter(view)

        RxJavaPlugins.setIoSchedulerHandler { Schedulers.trampoline() }
        RxJavaPlugins.setComputationSchedulerHandler { Schedulers.trampoline() }
        RxJavaPlugins.setNewThreadSchedulerHandler { Schedulers.trampoline() }
        RxAndroidPlugins.setInitMainThreadSchedulerHandler { Schedulers.trampoline() }

    }

    @Test
    fun tesGetLeagueList() {
        val league = LeagueEventList()
        val events: MutableList<LeagueEvent> = mutableListOf()
        val idLiga = "4328"
        val function = "eventspastleague"

        match.getLeagueSchedule(function, idLiga)
        Mockito.verify(view).stopLoading()
        Mockito.verify(view).showLeagueDisplay(events)
    }

        @Test
        fun tesGetAllLeagueData() {
            val leagues = arrayListOf<League>()
            var value = LeagueList(leagues)
            val mock = org.mockito.Mockito.mock<MatchSchedule>(MatchSchedule::class.java)
//        Mockito.`when`(mock.getAllLeagueData("eventspastleague")).thenReturn(value)
        }
    @Test
    fun testformatDayddMMMyyyy() {
        assertEquals("Mon, 01 Jan 2018", "2018-01-01".formatDayddMMMyyyy())
    }
}
